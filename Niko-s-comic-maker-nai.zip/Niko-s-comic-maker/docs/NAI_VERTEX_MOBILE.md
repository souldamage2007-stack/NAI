# NAI · Vertex AI · 휴대폰 작업실

이 판은 다섯 가지가 바뀌었다.

1. **그림 = NovelAI(NAI) API, 모델 V5 full** (`nai-diffusion-5-full`, ComfyUI 대신, 기본). 내 PC 그래픽카드·ComfyUI·모델 7GB가 필요 없다.
2. **글 AI = Google Vertex AI** (Ollama 대신, 기본). 서비스 계정 JSON 키 하나로 계획표 쓰기, 자동 검수, 한국어 고치기 요청 해석을 한다.
3. **휴대폰에서 작업실 쓰기**. 같은 와이파이의 휴대폰으로 만화를 만들고, 고치고, 결과를 본다.
4. **🎨 NAI 직접 그리기 · NAI 프롬프트**. 프롬프트·부정 프롬프트·캐릭터별 프롬프트(위치)를 직접 넣어 한 장씩 그린다. 모든 그림에 붙일 말(앞·뒤·부정)도 정한다.
5. **안드로이드 앱(APK)**. PC 없이 휴대폰만으로 NAI 그리기 + Vertex 프롬프트, PC 작업실 연결까지 한 앱에서.

예전 방식(ComfyUI · Ollama)도 그대로 있다. `presets.yaml`에서 `image_backend: comfy`, `llm: {backend: ollama}`로 바꾸면 된다.

---

## 1. 준비

```
python -m pip install -r requirements.txt     # cryptography(Vertex 로그인), qrcode(휴대폰 QR) 가 새로 들어감
```

### NAI 키
1. novelai.net 로그인 → 톱니(설정) → **Account** → **Get Persistent API Token** → 나온 글(`pst-…`)을 복사
2. 다음 중 하나로 넣는다
   - 작업실 오른쪽 위 **⚙ 설정** → NovelAI 키 칸에 붙여 넣고 저장
   - 명령: `.\nk.bat ep keys --nai` (입력해도 화면에 안 보임)
3. **Opus 구독**이면 1024×1024 이하 · 28걸음 이하 · 한 장씩 그리기는 Anlas를 안 쓴다. 기본값이 이 안에 맞춰져 있다 (`presets.yaml`의 `nai:`).
   다른 구독이면 그림마다 Anlas를 쓴다.

### Vertex AI 서비스 계정 JSON
1. Google Cloud 콘솔에서 프로젝트를 고르고 **Vertex AI API**를 사용 설정
2. IAM 및 관리자 → 서비스 계정 → 계정 만들기 → 역할 **Vertex AI 사용자 (roles/aiplatform.user)**
3. 그 계정 → 키 → 키 추가 → **JSON** → 파일이 내려받아짐
4. 다음 중 하나로 넣는다
   - 작업실 **⚙ 설정** → 파일 고르기(휴대폰에서도 됨) 또는 내용 붙여 넣기 → 저장
   - 명령: `.\nk.bat ep keys --vertex C:\내려받은\키.json`
5. 모델은 `presets.yaml`의 `llm.model` (기본 `gemini-2.5-flash`). 콘솔의 Model Garden에 없는 이름이면 `llm.fallback` 순서로 다음 모델을 시도한다. 지역은 `llm.location` (기본 `global`).

### 확인
```
.\nk.bat ep keys --test      # NAI: 구독 정보만 확인(그림 안 그림) / Vertex: 짧은 질문 하나
```
작업실 ⚙ 설정의 **연결 시험** 버튼도 같은 일을 한다.

**열쇠는 키트 폴더 밖** (`%APPDATA%\nk_keys`)에 저장된다. 키트 폴더를 남에게 줘도 열쇠는 안 따라간다.
환경 변수 `NK_NAI_KEY`, `NK_VERTEX_JSON`(파일 경로)이 있으면 그것이 먼저다.

---

## 2. 휴대폰으로 쓰기

1. PC에서 **휴대폰작업실.bat** 을 더블클릭 (= `.\nk.bat ep web --lan`)
2. Windows 방화벽 창이 뜨면 **개인 네트워크** 허용
3. PC 작업실 화면의 **📱 휴대폰** 버튼 → 나온 QR 코드를 휴대폰 카메라로 찍기 (검은 창에도 주소와 QR이 나온다)
4. 한 번 들어오면 60일 동안 기억한다. 홈 화면에 추가하면 앱처럼 열린다.

- 주소의 `t=…` 는 **비밀번호와 같다**. 남에게 보내지 말 것. 바꾸려면 `.\nk.bat ep web --lan --new-token` (예전 휴대폰은 다시 QR을 찍어야 함)
- 열쇠 없는 기기는 로그인 화면만 본다. 공유기 밖(인터넷)으로 포트를 열지 말 것.
- PC는 켜 둬야 한다 (그림은 NAI가 그리지만, 작업 줄·파일은 PC에 있다).

### 휴대폰에서 새 만화
**새 만화** → *요청 글 만들기* 를 펼쳐 칸을 채움 (또는 아래 칸에 요청을 직접 씀) → **✨ AI가 바로 계획표 쓰기**
→ Vertex AI가 계획표를 쓰고 → 바로 *글콘티 검사* → 통과하면 작업 줄에 들어간다. 에피소드 이름을 비우면 날짜로 지어 준다.

예전처럼 ChatGPT·Gemini 앱에서 받은 답을 붙여 넣는 방법도 그대로 된다.

---

## 3. 🎨 NAI 직접 그리기 · NAI 프롬프트

- PC 작업실 위쪽 **🎨 NAI 그리기** (주소 `/nai`), 또는 안드로이드 앱 첫 화면.
- **프롬프트 / 부정 프롬프트** 를 직접 쓰거나, **✨ 말로 설명하기** 에 한국어로 쓰면 Vertex AI 가 NAI 태그 프롬프트로 바꿔 채워 준다.
- **캐릭터** 를 두 명 이상 넣으면 사람마다 프롬프트·위치(왼쪽/가운데/오른쪽, 위/아래)를 따로 준다 (V5 캐릭터 프롬프트).
- 크기(세로·가로·정사각·길게), 고급 설정(모델·시드·걸음·scale·샘플러). 걸음 28 이하 · 1024×1024 이하면 Opus 무료.
- **⚙ 설정 → NAI 프롬프트**: 모든 그림(만화 컷 포함)에 붙이는 **앞에 붙일 말 / 뒤에 붙일 말 / 부정에 붙일 말**. 그림체·품질 태그를 여기에 넣으면 만화 전체에 먹는다.
  기본값은 `presets.yaml`의 `nai.prompt_prefix / prompt_suffix / negative_extra`, 화면에서 고친 값이 먼저다.
- PC 에서 그린 것은 `runs/nai_direct/` 에 그림 + 설정(.json)으로 남고, **기록** 탭에서 눌러 그 설정을 다시 불러온다.

## 4. 안드로이드 앱 (APK)

`android/` 폴더가 앱 소스다. GitHub 에 올리면 **Actions 가 APK 를 대신 만든다** (`.github/workflows/android-apk.yml`).
1. 이 폴더 전체를 GitHub 저장소에 올린다 (push).
2. 저장소의 **Actions** 탭에서 *Android APK* 가 초록 체크가 될 때까지 기다린다 (3~6분).
3. **Releases → apk-latest → NikoComicMaker.apk** 를 휴대폰에서 내려받아 설치 (설정에서 '출처를 알 수 없는 앱' 허용).
   Actions 가 안 돌면: Actions 탭 → Android APK → *Run workflow*.

앱에서 할 수 있는 것
- **🎨 그리기 / 기록 / ⚙ 설정**: 위 3번과 같은 화면. 휴대폰이 직접 NAI·Vertex 에 요청한다 (PC 필요 없음). 열쇠는 앱 안에만 저장.
  💾 저장 = 갤러리 `사진/NikoComic`.
- **💻 PC 작업실**: PC 의 휴대폰 모드 주소(`http://…:8765/?t=…`)를 넣으면 만화 전체 만들기를 앱 안에서. QR 코드를 카메라로 찍고 '만화 작업실'로 열어도 된다.
- 서명 열쇠는 `android/app/nk-release.jks` (비밀번호 `nikocomic`, 개인용). 공개 저장소면 Secrets 에 `NK_KEYSTORE_B64`·`NK_KEYSTORE_PASS`·`NK_KEY_ALIAS` 를 넣어 바꿀 수 있다 (바꾸면 예전 앱을 지우고 새로 설치).

## 5. NAI 모드에서 바뀌는 것

| 단계 | NAI 모드 |
|---|---|
| 모델 | `nai-diffusion-5-full` (V5). 부분 다시 그리기는 V5 전용 모델 이름이 아직 알려지지 않아 V4.5 inpainting 을 씀 (`nai.inpaint_model`) |
| 혼자 컷 · 사람 없는 컷 | NAI 한 장 (Anima 흐름과 같은 글 조립 → `@작가`는 `artist:작가`로) |
| 두 명 컷 | NAI V4.5 캐릭터별 글 + 위치(왼쪽/오른쪽) 한 장 — 두 사람 옷·생김새가 덜 섞임 |
| LoRA 캐릭터 | LoRA를 못 쓴다 → 캐릭터 파일의 태그·설명(`tags_full`, `anima`)으로 그린다 |
| 3D 인형 자세 · 얼굴 다듬기 · SAM3 머리 수 검사 · 부위만 다시 그리기 | ComfyUI 전용이라 건너뜀 (부위만 다시 그리기는 한국어로 알리고 멈춤) |
| 컷 다시 그리기 · 후보 3장 · 태그/문장 고치기 · 말풍선 · 표지 · PDF | 그대로 된다 |

전연령 안전장치는 그대로다. 긍정 글에서 막힌 말을 지우고, 부정 글에 `nsfw, explicit, nude …`와 성인 등급 태그를 늘 넣는다.
NAI는 모델이 성인 그림을 그릴 수 있으니 **결과를 직접 확인하는 책임은 사용자에게 있다** (USE_POLICY.md).

그린 기록은 `episodes/<화>/nai.json` (글·부정 글·시드·크기·모델).

## 6. 설정값 (`presets.yaml`)

```yaml
image_backend: nai          # comfy = 예전 ComfyUI
nai:
  model: nai-diffusion-5-full
  steps: 28
  scale: 5.0
  sampler: k_euler_ancestral
  max_pixels: 1048576       # 1024x1024 (Opus 무료 한도)
  prompt_prefix: "very aesthetic, masterpiece, no text"     # 모든 그림 앞에
  negative_extra: "lowres, artistic error, ..."              # 모든 그림 부정에
llm:
  backend: vertex           # ollama = 예전 Ollama
  model: gemini-2.5-flash
  location: global
```
환경 변수 `NK_BACKEND=comfy|nai`, `NK_LLM=ollama|vertex`, `NK_VERTEX_MODEL`, `NK_VERTEX_LOCATION` 이 있으면 그것이 먼저다.
