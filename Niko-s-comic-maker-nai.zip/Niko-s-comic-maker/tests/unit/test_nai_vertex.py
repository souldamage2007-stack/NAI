# -*- coding: utf-8 -*-
"""NAI 그리기·Vertex AI 글 AI 시험 (진짜 API 는 안 부름: _post / _call 을 가짜로)"""
import io
import json
import zipfile

import pytest
from PIL import Image


@pytest.fixture
def nai(tmp_path, monkeypatch):
    monkeypatch.setenv("NK_KEYS_DIR", str(tmp_path / "keys"))
    monkeypatch.setenv("NK_NAI_KEY", "pst-test")
    import nk_nai
    calls = []

    def fake_post(body, key, timeout):
        calls.append(body)
        p = body["parameters"]
        b = io.BytesIO()
        Image.new("RGB", (p["width"], p["height"])).save(b, "PNG")
        z = io.BytesIO()
        with zipfile.ZipFile(z, "w") as zf:
            zf.writestr("image_0.png", b.getvalue())
        return z.getvalue(), "application/x-zip-compressed"
    monkeypatch.setattr(nk_nai, "_post", fake_post)
    monkeypatch.setitem(nk_nai.DEFAULTS, "min_interval", 0)
    nk_nai.calls = calls
    return nk_nai


def test_anima_to_nai():
    import nk_nai
    t = nk_nai.anima_to_nai("masterpiece, best quality, score_7, safe, @some artist, 1girl, solo. A girl waves.")
    assert t == "rating:general, artist:some artist, 1girl, solo. A girl waves."


def test_fit_size():
    import nk_nai
    for w, h in [(832, 1216), (1536, 640), (512, 512), (2000, 300)]:
        a, b = nk_nai.fit_size(w, h, 1024 * 1024)
        assert a % 64 == 0 and b % 64 == 0 and a * b <= 1024 * 1024


def test_generate_two_characters_and_safety(nai):
    im = nai.generate("safe, 2girls, park", "score_1, worst quality", 1216, 832, 5,
                      chars=[{"prompt": "1girl, red hair", "x": 0.27}, {"prompt": "1girl, black hair", "x": 0.74}])
    body = nai.calls[-1]
    p = body["parameters"]
    assert im.size == (1216, 832) and body["action"] == "generate"
    assert [c["centers"][0]["x"] for c in p["v4_prompt"]["caption"]["char_captions"]] == [0.3, 0.7]
    assert "nsfw" in p["negative_prompt"] and "score_1" not in p["negative_prompt"]
    assert p["width"] * p["height"] <= 1024 * 1024 and p["steps"] <= 28


def test_inpaint_uses_inpainting_model(nai):
    src = Image.new("RGB", (640, 960))
    m = Image.new("L", (640, 960), 0)
    m.paste(255, (0, 0, 100, 100))
    nai.generate("a cat", "", image=src, mask=m, strength=0.6)
    assert nai.calls[-1]["action"] == "infill" and nai.calls[-1]["model"].endswith("-inpainting")


def test_comfy_graph_to_nai(nai, tmp_path):
    c = nai.NaiComfy("auto")
    g = {"5": {"class_type": "CLIPTextEncode", "inputs": {"text": "safe, @abc, 1boy", "clip": ["2", 0]}},
         "6": {"class_type": "CLIPTextEncode", "inputs": {"text": "worst quality", "clip": ["2", 0]}},
         "2": {"class_type": "CLIPLoader", "inputs": {}},
         "7": {"class_type": "EmptySD3LatentImage", "inputs": {"width": 832, "height": 1216, "batch_size": 1}},
         "8": {"class_type": "KSampler", "inputs": {"seed": 77, "denoise": 1.0, "positive": ["5", 0], "negative": ["6", 0],
                                                    "latent_image": ["7", 0], "model": ["1", 0]}},
         "9": {"class_type": "VAEDecode", "inputs": {"samples": ["8", 0]}},
         "10": {"class_type": "SaveImage", "inputs": {"images": ["9", 0]}}}
    outs = c.wait(c.queue(g), "t")
    dst = tmp_path / "o.png"
    c.fetch(outs["10"]["images"][0], str(dst))
    assert Image.open(dst).size == (832, 1216)
    assert nai.calls[-1]["parameters"]["seed"] == 77 and "artist:abc" in nai.calls[-1]["input"]
    g["11"] = {"class_type": "SAM3_Detect", "inputs": {}}
    g["9"]["inputs"]["samples"] = ["11", 0]
    with pytest.raises(SystemExit):
        c.wait(c.queue(g), "sam")


def test_vertex_conversion():
    import nk_vertex
    contents, system = nk_vertex._contents([{"role": "system", "content": "s"}, {"role": "user", "content": "a", "images": ["iVBORw0"]},
                                            {"role": "assistant", "content": "b"}, {"role": "user", "content": "c"}])
    assert system == "s" and [x["role"] for x in contents] == ["user", "model", "user"]
    assert contents[0]["parts"][0]["inlineData"]["mimeType"] == "image/png"
    sc = nk_vertex._schema({"type": "object", "properties": {"a": {"type": "array", "items": {"type": "string"}}}, "required": ["a"]})
    assert sc == {"type": "OBJECT", "properties": {"a": {"type": "ARRAY", "items": {"type": "STRING"}}}, "required": ["a"]}
    assert nk_vertex._text({"candidates": [{"content": {"parts": [{"text": "x", "thought": True}, {"text": "ok"}]}}]}) == "ok"


def test_backend_keys(tmp_path, monkeypatch):
    monkeypatch.setenv("NK_KEYS_DIR", str(tmp_path))
    monkeypatch.delenv("NK_NAI_KEY", raising=False)
    import nk_backend
    nk_backend.save_nai_key("Bearer pst-abc")
    assert nk_backend.nai_key() == "pst-abc"
    with pytest.raises(ValueError):
        nk_backend.save_vertex_json(json.dumps({"type": "user"}))
    st = nk_backend.status()
    assert st["nai_key"] and "pst-abc" not in json.dumps(st)
