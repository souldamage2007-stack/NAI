# -*- coding: utf-8 -*-
"""그림 엔진·글 AI 고르기와 열쇠(API 키) 보관

그림 엔진 (image_backend)
  nai   = NovelAI 이미지 API (기본). 내 PC 그래픽카드·ComfyUI 가 없어도 됨
  comfy = 예전처럼 내 PC 의 ComfyUI
  고르는 순서: 환경 변수 NK_BACKEND > presets.yaml 의 image_backend > nai

글 AI (llm_backend) — 계획표 쓰기, 자동 검수, 한국어 고치기 요청 해석, 캐릭터 태그 찾기
  vertex = Google Vertex AI (서비스 계정 JSON 키, 기본)
  ollama = 예전처럼 내 PC 의 Ollama
  고르는 순서: 환경 변수 NK_LLM > presets.yaml 의 llm.backend > vertex

열쇠 (키트 폴더 밖에 둠 — 키트 폴더를 남에게 줘도 열쇠는 안 따라감)
  폴더: 환경 변수 NK_KEYS_DIR, 없으면 %APPDATA%\\nk_keys (Windows) / ~/.nk_keys
  NAI 키      : 환경 변수 NK_NAI_KEY 또는 <폴더>/nai_key.txt
  Vertex JSON : 환경 변수 NK_VERTEX_JSON (또는 GOOGLE_APPLICATION_CREDENTIALS) 또는 <폴더>/vertex.json

명령: nk ep keys               지금 상태 보기
      nk ep keys --nai          NAI 키 넣기 (화면에 안 보이게 입력)
      nk ep keys --vertex 경로  서비스 계정 JSON 파일을 열쇠 폴더로 복사
      nk ep keys --test         NAI·Vertex 연결 시험 (NAI 는 그림 안 그림 = Anlas 안 씀)"""
import os
import sys
import json

KIT = os.path.dirname(os.path.abspath(__file__))


def keys_dir():
    d = os.environ.get("NK_KEYS_DIR")
    if not d:
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        d = os.path.join(base, "nk_keys" if os.environ.get("APPDATA") else ".nk_keys")
    return d


def _presets():
    try:
        import yaml
        with open(os.path.join(KIT, "presets.yaml"), encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}


def image_backend(cfg=None):
    v = os.environ.get("NK_BACKEND") or (cfg if cfg is not None else _presets()).get("image_backend") or "nai"
    v = str(v).strip().lower()
    return "comfy" if v in ("comfy", "comfyui", "local") else "nai"


def is_nai(cfg=None):
    return image_backend(cfg) == "nai"


def llm_backend(cfg=None):
    c = cfg if cfg is not None else _presets()
    v = os.environ.get("NK_LLM") or (c.get("llm") or {}).get("backend") or "vertex"
    v = str(v).strip().lower()
    return "ollama" if v in ("ollama", "local") else "vertex"


def is_vertex(cfg=None):
    return llm_backend(cfg) == "vertex"


def nai_settings(cfg=None):
    c = cfg if cfg is not None else _presets()
    return dict(c.get("nai") or {})


def llm_settings(cfg=None):
    c = cfg if cfg is not None else _presets()
    return dict(c.get("llm") or {})


# ---------------------------------------------------------------- 열쇠
def _read(p):
    try:
        with open(p, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def nai_key():
    k = (os.environ.get("NK_NAI_KEY") or "").strip() or _read(os.path.join(keys_dir(), "nai_key.txt"))
    return k or None


def vertex_json_path():
    for p in (os.environ.get("NK_VERTEX_JSON"), os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"),
              os.path.join(keys_dir(), "vertex.json")):
        if p and os.path.isfile(p):
            return p
    return None


def _write_secret(name, text):
    d = keys_dir()
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, name)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, p)
    return p


def save_nai_key(key):
    key = str(key or "").strip()
    if key.lower().startswith("bearer "):
        key = key[7:].strip()
    if not key or len(key) > 400 or any(ch.isspace() for ch in key):
        raise ValueError("NAI 키 모양이 이상함 (공백 없는 한 줄, 보통 pst- 로 시작)")
    return _write_secret("nai_key.txt", key)


def check_vertex_json(text):
    """서비스 계정 JSON 글 -> dict (모양 검사)"""
    try:
        d = json.loads(text)
    except Exception:
        raise ValueError("JSON 으로 읽을 수 없음 (Google Cloud 콘솔에서 받은 서비스 계정 키 파일 내용 전체)")
    if not isinstance(d, dict) or d.get("type") != "service_account" or not d.get("private_key") or not d.get("client_email"):
        raise ValueError("서비스 계정 키가 아님 (type: service_account, private_key, client_email 이 있어야 함)")
    if not d.get("project_id"):
        raise ValueError("project_id 가 없음")
    return d


def save_vertex_json(text):
    check_vertex_json(text)
    return _write_secret("vertex.json", text.strip() + "\n")


# ---------------------------------------------------------------- NAI 프롬프트 (모든 그림에 붙이는 말 · 사용자가 화면에서 고침)
PROMPT_KEYS = ("prefix", "suffix", "negative")


def nai_prompt(cfg=None):
    """모든 NAI 그림에 붙이는 말: prefix(앞) / suffix(뒤) / negative(부정).
    presets.yaml 의 nai.prompt_prefix / prompt_suffix / negative_extra 가 기본값, 화면(⚙ 설정)에서 고친 값(열쇠 폴더 nai_prompt.json)이 먼저"""
    ns = nai_settings(cfg)
    out = {"prefix": str(ns.get("prompt_prefix") or ""), "suffix": str(ns.get("prompt_suffix") or ""),
           "negative": str(ns.get("negative_extra") or "")}
    try:
        d = json.load(open(os.path.join(keys_dir(), "nai_prompt.json"), encoding="utf-8"))
        for k in PROMPT_KEYS:
            if isinstance(d.get(k), str):
                out[k] = d[k]
    except (OSError, ValueError):
        pass
    return out


def save_nai_prompt(d):
    cur = nai_prompt()
    for k in PROMPT_KEYS:
        if k in d:
            v = str(d[k] or "").replace("\r", " ").replace("\n", " ").strip()
            if len(v) > 2000:
                raise ValueError("프롬프트가 너무 김 (2000자까지)")
            cur[k] = v
    _write_secret("nai_prompt.json", json.dumps(cur, ensure_ascii=False, indent=1))
    return cur


def reset_nai_prompt():
    p = os.path.join(keys_dir(), "nai_prompt.json")
    if os.path.exists(p):
        os.remove(p)
    return nai_prompt()


def remove_key(which):
    p = os.path.join(keys_dir(), {"nai": "nai_key.txt", "vertex": "vertex.json"}[which])
    if os.path.exists(p):
        os.remove(p)


def status(cfg=None):
    """화면·명령에 보여 줄 상태 (열쇠 내용은 절대 안 넣음)"""
    c = cfg if cfg is not None else _presets()
    vp = vertex_json_path()
    proj = ""
    if vp:
        try:
            proj = json.load(open(vp, encoding="utf-8")).get("project_id", "")
        except Exception:
            proj = "(읽기 실패)"
    k = nai_key()
    ls = llm_settings(c)
    ns = nai_settings(c)
    return {"image": image_backend(c), "llm": llm_backend(c),
            "nai_key": bool(k), "nai_key_hint": ("…" + k[-4:]) if k else "",
            "nai_model": ns.get("model", "nai-diffusion-5-full"), "nai_prompt": nai_prompt(c),
            "vertex_json": bool(vp), "vertex_project": proj,
            "vertex_model": ls.get("model", "gemini-2.5-flash"), "vertex_location": ls.get("location", "global"),
            "keys_dir": keys_dir()}


# ---------------------------------------------------------------- nk ep keys
def run_keys(nk, kit, args):
    if args.nai:
        import getpass
        key = args.nai_value or getpass.getpass("NAI 영구 API 토큰 (novelai.net > 설정 > Account > Get Persistent API Token, 입력해도 화면에 안 보임): ")
        print("저장:", save_nai_key(key))
    if args.vertex:
        p = os.path.expanduser(args.vertex)
        if not os.path.isfile(p):
            print("[ERROR] 파일이 없음:", p); sys.exit(1)
        print("저장:", save_vertex_json(open(p, encoding="utf-8").read()))
    if args.forget:
        remove_key(args.forget)
        print("지움:", args.forget)
    st = status()
    print("그림 엔진  : %s%s" % (st["image"], "  (presets.yaml image_backend / 환경 변수 NK_BACKEND)"))
    print("글 AI      : %s" % st["llm"])
    print("NAI 키     : %s %s  모델 %s" % ("있음" if st["nai_key"] else "없음", st["nai_key_hint"], st["nai_model"]))
    print("Vertex JSON: %s %s  모델 %s @ %s" % ("있음" if st["vertex_json"] else "없음", st["vertex_project"],
                                              st["vertex_model"], st["vertex_location"]))
    print("열쇠 폴더  :", st["keys_dir"])
    if args.test:
        ok = True
        if st["nai_key"]:
            import nk_nai
            try:
                print("NAI 시험  :", nk_nai.check_key())
            except Exception as e:
                ok = False
                print("NAI 시험  : 실패 -", e)
        if st["vertex_json"]:
            import nk_vertex
            try:
                ans = nk_vertex.chat([{"role": "user", "content": "Reply with the single word: ok"}], temperature=0, max_tokens=20)
                print("Vertex 시험: 성공 (%s, 답 %r)" % (nk_vertex.last_model() or st["vertex_model"], ans.strip()[:20]))
            except Exception as e:
                ok = False
                print("Vertex 시험: 실패 -", e)
        if not ok:
            sys.exit(1)


def add_parser(esub, nk, kit):
    a = esub.add_parser("keys", help="NAI API key / Vertex AI service-account JSON: show, set, test")
    a.add_argument("--nai", action="store_true", help="enter the NAI persistent API token")
    a.add_argument("--nai-value", dest="nai_value", help=argparse_hidden())
    a.add_argument("--vertex", metavar="JSON", help="copy a Vertex AI service-account JSON key file into the key folder")
    a.add_argument("--forget", choices=["nai", "vertex"], help="delete a saved key")
    a.add_argument("--test", action="store_true", help="test both connections (NAI: account check only, no image)")
    a.set_defaults(func=lambda x: run_keys(nk, kit, x))


def argparse_hidden():
    import argparse
    return argparse.SUPPRESS
