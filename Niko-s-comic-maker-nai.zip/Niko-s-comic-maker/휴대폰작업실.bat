@echo off
REM phone mode: the comic workshop also opens on phones on the same Wi-Fi (scan the QR code on the PC page / window).
REM Close this window to stop. Never forward this port to the internet.
cd /d "%~dp0"
call "%~dp0nk.bat" ep web --lan
pause
