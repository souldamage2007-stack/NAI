# -*- coding: utf-8 -*-
"""NovelAI(NAI) 이미지 API 로 그리기 — ComfyUI 대신

왜: 내 PC 그래픽카드·ComfyUI·모델 7GB 없이도 만화를 그림 (휴대폰으로 작업실을 열어 둬도 PC 는 가볍게).

무엇
  1. generate()      NAI /ai/generate-image 한 번 (그리기 / img2img / 부분 다시 그리기 infill)
                     V5 (nai-diffusion-5-full) 여러 캐릭터 글(char_captions + 위치)로 두 명 컷을 한 장에 그림
  2. make_cuts()     콘티의 컷을 NAI 로 그림 (nk_auto 의 make 단계가 NAI 모드에서 부름)
                     글은 Anima 흐름과 같은 조립(nk_animacut.cut_text)을 쓰고 NAI 말로 바꿈 (@작가 -> artist:작가 등)
  3. NaiComfy        nk.Comfy 자리에 들어가는 대역. ComfyUI 그래프(글·크기·시드·img2img·마스크)를 읽어 NAI 로 그림
                     -> 표지·다시 그리기 같은 다른 단계도 그대로 돔. SAM3·Qwen 편집 같은 ComfyUI 전용 노드는 못 함 (한국어로 알리고 멈춤)

전연령 안전장치는 그대로: 긍정 글은 nk.safe_text 로 막힌 말을 지우고, 부정 글에는 nk.SAFE_NEG 와 성인 등급 태그를 늘 넣음.

비용: Opus 구독이면 1024x1024 이하 · 28걸음 이하 · 한 장씩이면 Anlas 를 안 씀 (기본값이 이 안에 맞춰져 있음).
설정: presets.yaml 의 nai: (모델·걸음·scale·sampler·최대 픽셀). 열쇠: nk ep keys --nai"""
import os
import re
import io
import sys
import json
import math
import time
import uuid
import random
import shutil
import zipfile
import tempfile
import urllib.request
import urllib.error

API = os.environ.get("NK_NAI_URL") or "https://image.novelai.net/ai/generate-image"     # NK_NAI_URL = 시험용 가짜 서버
USER_API = ("https://image.novelai.net/user/subscription", "https://api.novelai.net/user/subscription")   # 2026: image. 으로 옮김
DEFAULTS = {
    "model": "nai-diffusion-5-full",
    "steps": 28,
    "scale": 5.0,
    "sampler": "k_euler_ancestral",
    "noise_schedule": "karras",
    "cfg_rescale": 0.0,
    "uc_preset": 3,                 # V5 웹 화면과 같은 값 (품질·부정 말은 아래 prompt_prefix / negative_extra 로 직접)
    "quality_toggle": False,
    "max_pixels": 1024 * 1024,      # Opus 무료 한도
    "timeout": 180,
    "retries": 6,
    "min_interval": 1.0,            # 연달아 부를 때 사이 쉬는 초 (NAI 는 한 번에 한 장만)
}
MODELS = ["nai-diffusion-5-full", "nai-diffusion-5-curated", "nai-diffusion-4-5-full", "nai-diffusion-4-5-curated",
          "nai-diffusion-4-full", "nai-diffusion-4-curated"]
INPAINT = {
    # V5 전용 부분 다시 그리기 모델 이름은 아직 공개 자료가 없음 -> V4.5 부분 다시 그리기 모델을 씀 (presets.yaml nai.inpaint_model 로 바꿀 수 있음)
    "nai-diffusion-5-full": "nai-diffusion-4-5-full-inpainting",
    "nai-diffusion-5-curated": "nai-diffusion-4-5-curated-inpainting",
    "nai-diffusion-4-5-full": "nai-diffusion-4-5-full-inpainting",
    "nai-diffusion-4-5-curated": "nai-diffusion-4-5-curated-inpainting",
    "nai-diffusion-4-full": "nai-diffusion-4-full-inpainting",
    "nai-diffusion-4-curated": "nai-diffusion-4-curated-inpainting",
    "nai-diffusion-3": "nai-diffusion-3-inpainting",
    "nai-diffusion-3-furry": "nai-diffusion-furry-3-inpainting",
}
SAFE_UC = "rating:explicit, rating:questionable, rating:sensitive, nsfw, nude, suggestive"
GRID = (0.1, 0.3, 0.5, 0.7, 0.9)
_last_call = [0.0]


class NaiError(RuntimeError):
    pass


def _nk():
    """nk 모듈 (nk.py 를 바로 실행했으면 __main__)"""
    m = sys.modules.get("nk")
    if m is None:
        main = sys.modules.get("__main__")
        if main is not None and hasattr(main, "safe_text") and hasattr(main, "SAFE_NEG"):
            return main
        import nk as m
    return m


def settings(cfg=None):
    import nk_backend
    s = dict(DEFAULTS)
    s.update({k: v for k, v in nk_backend.nai_settings(cfg).items() if v is not None})
    return s


def _key():
    import nk_backend
    k = nk_backend.nai_key()
    if not k:
        raise NaiError("NAI 키가 없음 -> 작업실 '⚙ 설정'에 넣거나 명령: nk ep keys --nai")
    return k


# ---------------------------------------------------------------- 글 바꾸기 (Anima -> NAI)
_TAG_DROP = re.compile(r"(?:(?<=^)|(?<=,))\s*(?:score_\d+(?:_up)?|masterpiece|best quality|newest|absurdres|highres)\s*(?=,|\.|$)", re.I)
_SAFE_TAG = re.compile(r"(?:(?<=^)|(?<=,))(\s*)safe(\s*)(?=,|\.|$)", re.I)


def anima_to_nai(text):
    """Anima 글 -> NAI 글: '@작가' -> 'artist:작가', score_N·품질 태그 빼기 (NAI 가 품질 태그를 붙임), safe -> rating:general"""
    t = str(text or "")
    t = re.sub(r"(^|[\s,])@([^,.;@]+)", lambda m: "%sartist:%s" % (m.group(1), m.group(2).strip()), t)
    t = _TAG_DROP.sub("", t)
    t = _SAFE_TAG.sub(lambda m: "%srating:general%s" % (m.group(1), m.group(2)), t)
    t = re.sub(r"\s*,(?:\s*,)+", ",", t)
    t = re.sub(r"^[\s,]+", "", t)
    t = re.sub(r"[ \t]{2,}", " ", t)
    return t.strip(" ,")


def _neg_clean(text):
    t = re.sub(r"(?:(?<=^)|(?<=,))\s*score_\d+(?:_up)?\s*(?=,|$)", "", str(text or ""), flags=re.I)
    return re.sub(r"\s*,(?:\s*,)+", ",", t).strip(" ,")


def _safe_pos(t):
    return _nk().safe_text(anima_to_nai(t)) or ""


def _safe_neg(t):
    nk = _nk()
    t = _neg_clean(t)
    have = t.lower()
    add = [x for x in (nk.SAFE_NEG + ", " + SAFE_UC).split(", ") if x.strip() and x.strip().lower() not in have]
    return ", ".join(x for x in [t] + add if x.strip())


def _snap(v):
    return min(GRID, key=lambda g: abs(g - float(v)))


# ---------------------------------------------------------------- 크기
def fit_size(w, h, max_px):
    """NAI 크기: 64의 배수, 넓이 <= max_px, 비율 유지. 작은 컷은 키워서 화질을 살림"""
    w, h = max(64, int(w)), max(64, int(h))
    k = math.sqrt(float(max_px) / (w * h))
    nw, nh = int(w * k) // 64 * 64, int(h * k) // 64 * 64
    nw, nh = max(64, min(nw, 1600)), max(64, min(nh, 1600))
    while nw * nh > max_px:
        if nw >= nh:
            nw -= 64
        else:
            nh -= 64
    return nw, nh


def _png_b64(im):
    import base64
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")


# ---------------------------------------------------------------- API
def _post(body, key, timeout):
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(API, data=data, headers={"Authorization": "Bearer " + key, "Content-Type": "application/json",
                                                          "Accept": "application/x-zip-compressed, image/png"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read(), r.headers.get("Content-Type", "")


def _unpack(raw, ctype):
    if raw[:4] == b"PK\x03\x04" or "zip" in ctype:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = sorted(n for n in z.namelist() if n.lower().endswith(".png"))
            if not names:
                raise NaiError("NAI 답에 그림이 없음")
            return z.read(names[0])
    if raw[:8] == b"\x89PNG\r\n\x1a\n":
        return raw
    if raw[:5] == b"data:" or b"event:" in raw[:200]:       # 스트림 모양으로 왔을 때
        import base64
        m = re.findall(rb"data:\s*(\{.*?\})\s*$", raw, re.M)
        for j in reversed(m):
            try:
                d = json.loads(j)
                if d.get("image"):
                    return base64.b64decode(d["image"])
            except Exception:
                continue
    raise NaiError("NAI 답을 읽을 수 없음 (%s, %d bytes)" % (ctype or "?", len(raw)))


def _explain(code, text):
    t = (text or "")[:300]
    if code == 401:
        return "NAI 키가 틀렸거나 만료됨 (401) -> 작업실 ⚙ 설정에서 키를 다시 넣기"
    if code == 402:
        return "NAI 구독·Anlas 가 모자람 (402). Opus 가 아니면 그림마다 Anlas 를 씀: %s" % t
    if code == 400:
        return "NAI 가 요청을 거절함 (400): %s" % t
    return "NAI 오류 %s: %s" % (code, t)


def _join(*parts):
    return ", ".join(p.strip(" ,") for p in parts if p and p.strip(" ,"))


def generate(prompt, negative="", width=832, height=1216, seed=None, chars=None, image=None, mask=None,
             strength=0.6, noise=0.0, cfg=None, user_prompt=True, convert=True, **over):
    """한 장 그림 -> PIL.Image (요청한 width x height 로 맞춰서 돌려줌). 쓴 시드는 generate.last_seed
    chars: [{"prompt": 글, "uc": 부정 글, "x": 0~1, "y": 0~1}] (두 명 컷)
    image: PIL 그림이면 img2img (strength = 얼마나 바꿀지 0~1), mask 도 있으면 그 자리만 다시 그림 (흰색 = 다시 그림)
    user_prompt: 사용자가 정한 'NAI 프롬프트'(앞·뒤·부정에 붙이는 말, ⚙ 설정 / presets.yaml nai.prompt_*)를 붙임
    convert: Anima 글(@작가·score 태그)을 NAI 말로 바꿈. 사람이 NAI 글을 직접 쓴 것(🎨 직접 그리기)은 False"""
    from PIL import Image
    import nk_backend
    st = settings(cfg)
    st.update({k: v for k, v in over.items() if v is not None})
    key = _key()
    W, H = int(width), int(height)
    if image is not None:
        W, H = image.size
    nw, nh = fit_size(W, H, int(st["max_pixels"]))
    steps = max(1, int(st["steps"]))
    if steps > 28 and int(st["max_pixels"]) <= 1024 * 1024 and not st.get("allow_paid"):
        steps = 28                                           # Opus 무료 한도
    seed = int(seed if seed not in (None, "") else random.randint(1, 2 ** 32 - 2)) % (2 ** 32 - 1)
    generate.last_seed = seed
    up = nk_backend.nai_prompt(cfg) if user_prompt else {}
    nk = _nk()
    body_txt = anima_to_nai(prompt) if convert else str(prompt or "")
    pos = nk.safe_text(_join(up.get("prefix"), body_txt, up.get("suffix"))) or ""
    neg = _safe_neg(_join(up.get("negative"), negative))
    chars = [c for c in (chars or []) if str(c.get("prompt") or "").strip()]
    model = st["model"]
    v5 = "diffusion-5" in model
    params = {
        "params_version": 4 if v5 else 3, "width": nw, "height": nh, "scale": float(st["scale"]), "sampler": st["sampler"],
        "steps": steps, "n_samples": 1, "ucPreset": int(st["uc_preset"]), "qualityToggle": bool(st["quality_toggle"]),
        "autoSmea": False, "dynamic_thresholding": False, "controlnet_strength": 1, "legacy": False,
        "add_original_image": True, "cfg_rescale": float(st["cfg_rescale"]), "noise_schedule": st["noise_schedule"],
        "legacy_v3_extend": False, "skip_cfg_above_sigma": None, "use_coords": bool(chars), "legacy_uc": False,
        "normalize_reference_strength_multiple": True, "seed": seed, "negative_prompt": neg,
        "deliberate_euler_ancestral_bug": False, "prefer_brownian": True,
        "characterPrompts": [], "v4_prompt": {"caption": {"base_caption": pos, "char_captions": []}, "use_coords": bool(chars),
                                              "use_order": True},
        "v4_negative_prompt": {"caption": {"base_caption": neg, "char_captions": []}, "legacy_uc": False},
    }
    if v5:                                                   # V5 웹 화면이 보내는 모양 (prompt 를 parameters 에도)
        params.update({"prompt": pos, "extra_noise_seed": seed, "uncond_scale": 1.0, "sm": False, "sm_dyn": False,
                       "reference_image_multiple": [], "reference_information_extracted_multiple": [],
                       "reference_strength_multiple": []})
    for c in chars:
        x, y = _snap(c.get("x", 0.5)), _snap(c.get("y", 0.5))
        cp = _safe_pos(c["prompt"]) if convert else (nk.safe_text(str(c["prompt"])) or "")
        cu = _neg_clean(c.get("uc") or "")
        params["characterPrompts"].append({"prompt": cp, "uc": cu, "center": {"x": x, "y": y}, "enabled": True})
        params["v4_prompt"]["caption"]["char_captions"].append({"char_caption": cp, "centers": [{"x": x, "y": y}]})
        params["v4_negative_prompt"]["caption"]["char_captions"].append({"char_caption": cu, "centers": [{"x": x, "y": y}]})
    action = "generate"
    if image is not None:
        src = image.convert("RGB").resize((nw, nh), Image.LANCZOS)
        params.update({"image": _png_b64(src), "strength": max(0.01, min(0.99, float(strength))), "noise": float(noise or 0),
                       "extra_noise_seed": seed})
        action = "img2img"
        if mask is not None:
            m = mask.convert("L").resize((nw, nh), Image.NEAREST).point(lambda v: 255 if v >= 128 else 0)
            if not m.getbbox():
                return image.copy()                          # 다시 그릴 자리가 없음
            params.update({"mask": _png_b64(m.convert("RGB")), "add_original_image": True,
                           "inpaintImg2ImgStrength": max(0.01, min(1.0, float(strength)))})
            model = st.get("inpaint_model") or INPAINT.get(model, model + "-inpainting")
            action = "infill"
            if "diffusion-5" not in model:
                params["params_version"] = 3
    body = {"input": pos, "model": model, "action": action, "parameters": params}
    raw = _call(body, key, st)
    im = Image.open(io.BytesIO(raw))
    im.load()
    if im.size != (W, H):
        im = im.resize((W, H), Image.LANCZOS)
    return im


def _call(body, key, st):
    tries = int(st.get("retries", 6))
    for k in range(tries):
        wait = float(st.get("min_interval", 1.0)) - (time.time() - _last_call[0])
        if wait > 0:
            time.sleep(wait)
        try:
            raw, ct = _post(body, key, int(st.get("timeout", 180)))
            _last_call[0] = time.time()
            return _unpack(raw, ct)
        except urllib.error.HTTPError as e:
            _last_call[0] = time.time()
            txt = e.read().decode("utf-8", "replace")
            if e.code in (429, 500, 502, 503, 504) and k < tries - 1:
                s = min(60, 3 * (2 ** k)) + random.random()
                print("   NAI %s (%s) -> %.0f초 뒤 다시" % (e.code, "동시 요청 한도" if e.code == 429 else "서버 오류", s))
                time.sleep(s)
                continue
            raise NaiError(_explain(e.code, txt))
        except (urllib.error.URLError, OSError) as e:
            _last_call[0] = time.time()
            if k < tries - 1:
                s = min(60, 3 * (2 ** k))
                print("   NAI 연결 실패 (%s) -> %d초 뒤 다시" % (e, s))
                time.sleep(s)
                continue
            raise NaiError("NAI 에 연결할 수 없음: %s" % e)
    raise NaiError("NAI 가 계속 응답하지 않음")


def check_key():
    """구독 정보만 봄 (그림 안 그림)"""
    d, err = None, None
    for u in USER_API:
        req = urllib.request.Request(u, headers={"Authorization": "Bearer " + _key()})
        try:
            d = json.loads(urllib.request.urlopen(req, timeout=20).read().decode("utf-8"))
            break
        except urllib.error.HTTPError as e:
            err = NaiError(_explain(e.code, e.read().decode("utf-8", "replace")))
            if e.code in (401, 402):
                break
        except (urllib.error.URLError, OSError, ValueError) as e:
            err = NaiError("NAI 에 연결할 수 없음: %s" % e)
    if d is None:
        raise err
    tier = {0: "Paper(무료)", 1: "Tablet", 2: "Scroll", 3: "Opus"}.get(d.get("tier"), str(d.get("tier")))
    anl = d.get("trainingStepsLeft") or {}
    left = (anl.get("fixedTrainingStepsLeft") or 0) + (anl.get("purchasedTrainingSteps") or 0)
    return "성공 — 구독 %s, Anlas %s%s" % (tier, left, "" if d.get("tier") == 3 else " (Opus 가 아니면 그림마다 Anlas 를 씀)")


# ---------------------------------------------------------------- 컷 그리기 (nk_auto make 단계)
def _nolora(ch):
    if not ch:
        return ch
    return {k: v for k, v in ch.items() if k not in ("anima_lora", "anima_lora_desc", "lora", "anima_lora_strength")}


def _cut_nolora(cut):
    """NAI 는 LoRA 를 못 씀 -> LoRA 캐릭터도 태그·설명으로 그림"""
    c = dict(cut)
    if c.get("_char"):
        c["_char"] = _nolora(c["_char"])
    if c.get("_roles"):
        c["_roles"] = [(r, _nolora(ch)) for r, ch in c["_roles"]]
    return c


def _strip_duo(text, regs):
    """Anima 두 명 글의 'On the left is A, (A 동작); on the right is B, (B 동작).' 를 뺌 -> 사람마다 글은 캐릭터 글로.
    설명 문장 안에 마침표가 있을 수 있어서 오른쪽 사람의 동작 태그(rp) 뒤 첫 마침표까지를 뺌"""
    i = text.find("On the left is ")
    j = text.find("; on the right is ", i + 1) if i >= 0 else -1
    if i < 0 or j < 0:
        return text
    rp = str((sorted(regs, key=lambda r: r["span"][0])[-1] or {}).get("rp") or "").strip()
    k = text.find(rp, j) if rp else -1
    if k >= 0:
        end = text.find(".", k + len(rp))
    else:
        m = re.compile(r"\.(?=\s|$)").search(text, j)
        end = m.start() if m else -1
    if end < 0:
        return text
    return (text[:i].rstrip() + " " + text[end + 1:].lstrip()).strip()


def cut_request(nk, W, cfg, conti, cut, artist):
    """컷 하나 -> (글, 부정 글, 폭, 높이, 캐릭터 글 목록)"""
    import nk_animacut as A
    cut = _cut_nolora(cut)
    s, text = A.cut_text(nk, W, cfg, conti, cut, artist)
    w, h = [int(x) for x in s["size"].split("x")] if isinstance(s.get("size"), str) else (int(s["width"]), int(s["height"]))
    neg = A.cut_neg(s, conti)
    if any(A.gaze_people(conti, cut)) and "looking at viewer" not in str(cut.get("scene") or "").lower():
        neg += ", looking at viewer"
    if str(cut.get("shot")) == "hands":
        neg += ", self grab, holding own wrist, face, head, eyes, hair, split screen, multiple views, 2koma"
    cn = A.char_negs(conti, cut, W)
    if cn:
        neg += ", " + cn
    chars = []
    if cut.get("_roles") and W._is_duo(cut):
        try:
            import nk_pose
            regs = nk_pose._cut_prompt(nk, W, cfg, conti, cut)[2] or []
        except SystemExit:
            regs = []
        if len(regs) >= 2:
            text = _strip_duo(text, regs)                    # 사람마다 글은 캐릭터 글로 (두 사람 모습이 덜 섞임)
            for r in sorted(regs, key=lambda r: r["span"][0]):
                ch = r.get("char") or {}
                desc = str(ch.get("anima") or "").strip()
                cap = ", ".join(x for x in (str(r.get("posL") or "").strip(" ,"), desc) if x)
                chars.append({"prompt": cap, "uc": str(ch.get("negative_extra") or ""),
                              "x": (float(r["span"][0]) + float(r["span"][1])) / 2.0, "y": 0.5})
    return text, neg, w, h, chars


def make_cuts(nk, kit, ep, cuts=None, force=False, dry=False, base_seed="500"):
    """콘티의 컷을 NAI 로 그림 -> episodes/<ep>/cuts/cutNN.png + nai.json. 돌려줌: 끝 코드 (0 = 다 그림)"""
    import nk_webtoon as W, nk_animacut as A
    cfg = nk.load_presets()
    conti = W.load_conti(nk, kit, ep)
    artist = conti.get("artist", "")
    ids = [int(x) for x in (cuts or [])] or [int(c["id"]) for c in conti["cuts"]]
    rec_p = os.path.join(W.ep_dir(kit, ep), "nai.json")
    try:
        rec = json.load(open(rec_p, encoding="utf-8"))
    except Exception:
        rec = {}
    st = settings(cfg)
    print("NAI make %s: %d cuts | %s %s steps scale %s | artist %s" % (ep, len(ids), st["model"], st["steps"], st["scale"], artist or "-"))
    made, failed = 0, []
    for cut in conti["cuts"]:
        cid = int(cut["id"])
        if cid not in ids:
            continue
        dst = W._final_file(kit, ep, cid)
        if os.path.exists(dst) and not force:
            print("[skip] cut %d: exists" % cid)
            continue
        text, neg, w, h, chars = cut_request(nk, W, cfg, conti, cut, artist)
        seed = A.cut_seed(ep, cut, base_seed)
        print("\n== cut %d %dx%d seed %d%s\n  %s" % (cid, w, h, seed, (" | %d characters" % len(chars)) if chars else "",
                                                     anima_to_nai(text)[:400]))
        for c in chars:
            print("   [%.1f] %s" % (c["x"], anima_to_nai(c["prompt"])[:200]))
        if dry:
            continue
        t0 = time.time()
        try:
            im = generate(text, neg, w, h, seed, chars, cfg=cfg)
        except NaiError as e:
            print("[ERROR] cut %d: %s" % (cid, e))
            failed.append(cid)
            if "키" in str(e) or "401" in str(e) or "402" in str(e):
                break                                         # 키·Anlas 문제는 다음 컷도 똑같이 실패
            continue
        if os.path.exists(dst):
            alt = os.path.join(W.ep_dir(kit, ep), "_alt")
            os.makedirs(alt, exist_ok=True)
            shutil.copy(dst, os.path.join(alt, "cut%02d_%s.png" % (cid, time.strftime("%m%d_%H%M"))))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        tmp = dst + ".tmp.png"
        im.save(tmp)
        os.replace(tmp, dst)
        rec[str(cid)] = {"text": anima_to_nai(text), "negative": neg, "chars": chars, "seed": seed, "size": [w, h],
                         "model": st["model"], "secs": round(time.time() - t0, 1), "time": time.strftime("%Y-%m-%d %H:%M:%S")}
        json.dump(rec, open(rec_p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        made += 1
        print("   saved %s (%.0f s)" % (dst, time.time() - t0))
    print("\nNAI make %s: %d cuts drawn%s" % (ep, made, (", failed %s" % failed) if failed else ""))
    return 1 if failed else 0


# ---------------------------------------------------------------- nk.Comfy 대역 (ComfyUI 그래프 -> NAI)
SAMPLERS = ("KSampler", "KSamplerAdvanced", "SamplerCustom", "SamplerCustomAdvanced")
OUTPUTS = ("SaveImage", "PreviewImage")
EMPTY = ("EmptyLatentImage", "EmptySD3LatentImage", "EmptyHunyuanLatentVideo", "EmptyLTXVLatentVideo", "EmptyMochiLatentVideo")
NOT_HERE = re.compile(r"SAM3|SAM2|SAMLoader|SAMDetector|Qwen|IPAdapter|Segment|Detector|Ultralytics|Detailer|Florence|GroundingDino|"
                      r"InContext|RefEncode|Kontext")      # 대소문자 구별 (KSampler 의 'Sam' 이 걸리지 않게)


class NaiUnsupported(RuntimeError):
    pass


class NaiComfy:
    """nk.Comfy 와 같은 모양 (queue / wait / fetch / cancel / free / upload_input / _get).
    queue 는 그래프를 받아 두기만 하고, wait 에서 NAI 로 그림"""
    is_nai = True

    def __init__(self, server=None):
        _key()                                            # 키가 없으면 여기서 바로 알림
        self.base = "nai://" + settings()["model"]
        self.client_id = str(uuid.uuid4())
        self._jobs = {}
        self._tmp = os.path.join(tempfile.gettempdir(), "nk_nai")
        os.makedirs(self._tmp, exist_ok=True)
        self._noted = set()

    # -- ComfyUI 흉내
    def _get(self, path):
        if path.startswith("/system_stats"):
            return {"system": {"backend": "nai"}, "devices": []}
        if path.startswith("/queue"):
            return {"queue_running": [], "queue_pending": []}
        return {}                                         # /object_info = 노드 없음 -> 그 기능은 꺼진 길로

    def _post(self, path, data):
        return {}

    def free(self):
        pass

    def cancel(self, pids):
        for p in pids or []:
            self._jobs.pop(p, None)

    def upload_input(self, path, name, subfolder=None):
        dst = os.path.join(self._tmp, "%s_%s" % (uuid.uuid4().hex[:8], os.path.basename(name)))
        shutil.copy(path, dst)
        return "@local:" + dst

    def queue(self, graph, raw=False):
        nk = _nk()
        nk.safe_graph(graph)                              # 전연령 안전장치 (ComfyUI 와 똑같이)
        pid = uuid.uuid4().hex
        self._jobs[pid] = graph
        return pid

    def wait(self, pid, label="", timeout=None, poll=1.0):
        g = self._jobs.pop(pid, None)
        if g is None:
            return {}
        try:
            return self._render(g, label)
        except NaiUnsupported as e:
            print("[ERROR] NAI 모드에서는 안 되는 그리기: %s" % e)
            print("        (ComfyUI 전용 기능. 이 컷은 '다시 그리기'·태그·문장 고치기로 바꿔 줘. ComfyUI 로 돌리려면 presets.yaml image_backend: comfy)")
            sys.exit(1)
        except NaiError as e:
            print("[ERROR] %s" % e)
            sys.exit(1)

    def fetch(self, img, dest):
        shutil.copy(img["filename"], dest)

    # -- 그래프 읽기
    def _note(self, what):
        if what not in self._noted:
            self._noted.add(what)
            print("   [NAI] %s" % what)

    def _render(self, g, label):
        self._g, self._cache = g, {}
        outs = {}
        for nid, n in g.items():
            if isinstance(n, dict) and n.get("class_type") in OUTPUTS:
                ref = (n.get("inputs") or {}).get("images")
                if not isinstance(ref, list):
                    continue
                im = self._image(ref)
                p = os.path.join(self._tmp, "%s_%s.png" % (re.sub(r"[^\w.-]", "_", label or "nai")[:40], uuid.uuid4().hex[:8]))
                im.save(p)
                outs[str(nid)] = {"images": [{"filename": p, "subfolder": "", "type": "nai"}]}
        if not outs:
            raise NaiUnsupported("그래프에 저장 노드(SaveImage)가 없음")
        print("   NAI: %s 그림 %d장" % (label, len(outs)))
        return outs

    def _node(self, ref):
        nid = str(ref[0])
        n = self._g.get(nid)
        if not isinstance(n, dict):
            raise NaiUnsupported("노드 %s 가 없음" % nid)
        ct = str(n.get("class_type") or "")
        if NOT_HERE.search(ct):
            raise NaiUnsupported("ComfyUI 전용 노드 %s" % ct)
        return nid, ct, n.get("inputs") or {}

    def _val(self, v, keys=("value", "seed", "noise_seed", "int", "float")):
        if isinstance(v, list) and len(v) == 2 and str(v[0]) in self._g:
            ins = (self._g[str(v[0])].get("inputs") or {})
            for k in keys:
                if k in ins:
                    return self._val(ins[k], keys)
            return None
        return v

    # 이미지
    def _image(self, ref):
        key = ("img", str(ref[0]), int(ref[1]) if len(ref) > 1 else 0)
        if key in self._cache:
            return self._cache[key]
        from PIL import Image
        nid, ct, ins = self._node(ref)
        if ct in ("VAEDecode", "VAEDecodeTiled"):
            im = self._latent_image(ins["samples"])
        elif ct in ("LoadImage", "LoadImageOutput"):
            im = self._load(ins.get("image")).convert("RGB")
        elif ct in ("ImageScale", "ImageScaleBy", "ImageScaleToTotalPixels", "ImageUpscaleWithModel"):
            src = self._image(ins.get("image"))
            if ct == "ImageScale":
                size = (int(self._val(ins.get("width")) or src.width), int(self._val(ins.get("height")) or src.height))
            elif ct == "ImageScaleBy":
                f = float(self._val(ins.get("scale_by")) or 1.0)
                size = (int(src.width * f), int(src.height * f))
            elif ct == "ImageScaleToTotalPixels":
                mp = float(self._val(ins.get("megapixels")) or 1.0) * 1024 * 1024
                f = math.sqrt(mp / (src.width * src.height))
                size = (int(src.width * f), int(src.height * f))
            else:
                size = (src.width * 2, src.height * 2)
            im = src.resize(size, Image.LANCZOS)
        elif ct == "MaskToImage":
            im = self._mask(ins.get("mask")).convert("RGB")
        elif ct == "EmptyImage":
            c = int(self._val(ins.get("color")) or 0)
            im = Image.new("RGB", (int(self._val(ins.get("width")) or 512), int(self._val(ins.get("height")) or 512)),
                           ((c >> 16) & 255, (c >> 8) & 255, c & 255))
        elif ct == "ImageCrop":
            src = self._image(ins.get("image"))
            x, y = int(self._val(ins.get("x")) or 0), int(self._val(ins.get("y")) or 0)
            im = src.crop((x, y, x + int(self._val(ins.get("width")) or src.width), y + int(self._val(ins.get("height")) or src.height)))
        elif ct == "ImageBlur":
            from PIL import ImageFilter
            im = self._image(ins.get("image")).filter(ImageFilter.GaussianBlur(int(self._val(ins.get("blur_radius")) or 1)))
        elif ct == "ImageCompositeMasked":
            dst = self._image(ins.get("destination")).copy()
            src = self._image(ins.get("source"))
            m = self._mask(ins["mask"]).resize(src.size) if isinstance(ins.get("mask"), list) else None
            if str(ins.get("resize_source", False)).lower() == "true":
                src = src.resize(dst.size, Image.LANCZOS)
                m = m.resize(dst.size) if m is not None else None
            dst.paste(src, (int(self._val(ins.get("x")) or 0), int(self._val(ins.get("y")) or 0)), m)
            im = dst
        else:
            raise NaiUnsupported("그림 노드 %s" % ct)
        self._cache[key] = im
        return im

    def _load(self, v):
        from PIL import Image
        v = str(v or "")
        if v.startswith("@local:"):
            p = v[len("@local:"):]
        elif v.startswith("@file:"):
            p = v[len("@file:"):]
        else:
            p = v if os.path.isabs(v) else ""
        if not p or not os.path.exists(p):
            raise NaiUnsupported("ComfyUI input 폴더의 그림 (%s) — NAI 모드에서는 못 읽음" % v)
        return Image.open(p)

    def _mask(self, ref):
        from PIL import Image, ImageOps, ImageFilter
        nid, ct, ins = self._node(ref)
        idx = int(ref[1]) if len(ref) > 1 else 0
        if ct in ("LoadImage",) and idx == 1:
            im = self._load(ins.get("image"))
            if "A" in im.getbands():
                return ImageOps.invert(im.getchannel("A"))      # ComfyUI: 마스크 = 1 - 알파
            return Image.new("L", im.size, 0)
        if ct == "LoadImageMask":
            im = self._load(ins.get("image"))
            ch = {"red": "R", "green": "G", "blue": "B", "alpha": "A"}.get(str(ins.get("channel", "alpha")), "A")
            if ch not in im.getbands():
                im = im.convert("RGBA")
            m = im.getchannel(ch)
            return ImageOps.invert(m) if ch == "A" else m
        if ct == "ImageToMask":
            im = self._image(ins.get("image"))
            ch = {"red": 0, "green": 1, "blue": 2}.get(str(ins.get("channel", "red")), 0)
            return im.convert("RGB").split()[ch]
        if ct == "InvertMask":
            return ImageOps.invert(self._mask(ins.get("mask")))
        if ct == "GrowMask":
            m = self._mask(ins.get("mask"))
            e = int(self._val(ins.get("expand")) or 0)
            if e > 0:
                return m.filter(ImageFilter.MaxFilter(e * 2 + 1))
            if e < 0:
                return m.filter(ImageFilter.MinFilter(-e * 2 + 1))
            return m
        if ct in ("FeatherMask", "ThresholdMask", "MaskBlur"):
            return self._mask(ins.get("mask"))
        if ct == "MaskComposite":
            from PIL import ImageChops
            d, s = self._mask(ins.get("destination")), self._mask(ins.get("source"))
            canvas = Image.new("L", d.size, 0)
            canvas.paste(s, (int(self._val(ins.get("x")) or 0), int(self._val(ins.get("y")) or 0)))
            op = str(ins.get("operation", "multiply"))
            f = {"multiply": ImageChops.multiply, "add": ImageChops.add, "subtract": ImageChops.subtract,
                 "and": ImageChops.darker, "or": ImageChops.lighter, "xor": ImageChops.difference}.get(op)
            if f is None:
                raise NaiUnsupported("마스크 합치기 %s" % op)
            return f(d, canvas)
        if ct == "SolidMask":
            v = float(self._val(ins.get("value")) or 1.0)
            return Image.new("L", (int(ins.get("width", 1024)), int(ins.get("height", 1024))), int(255 * v))
        raise NaiUnsupported("마스크 노드 %s" % ct)

    # 잠재 -> 그림 (샘플러 하나 = NAI 한 번)
    def _latent_image(self, ref):
        key = ("lat", str(ref[0]), int(ref[1]) if len(ref) > 1 else 0)
        if key in self._cache:
            return self._cache[key]
        nid, ct, ins = self._node(ref)
        if ct in SAMPLERS:
            im = self._sample(nid, ct, ins)
        else:
            src = self._latent_src(ref)
            if src[0] == "empty":
                raise NaiUnsupported("샘플러 없이 빈 잠재를 그림으로 바꿈")
            im = src[1]
        self._cache[key] = im
        return im

    def _latent_src(self, ref):
        """-> ("empty", w, h) / ("image", PIL, mask 또는 None)"""
        from PIL import Image
        nid, ct, ins = self._node(ref)
        if ct in EMPTY:
            return ("empty", int(self._val(ins.get("width")) or 1024), int(self._val(ins.get("height")) or 1024))
        if ct in SAMPLERS:
            return ("image", self._latent_image(ref), None)
        if ct in ("VAEEncode", "VAEEncodeTiled"):
            return ("image", self._image(ins["pixels"]), None)
        if ct == "VAEEncodeForInpaint":
            return ("image", self._image(ins["pixels"]), self._mask(ins["mask"]))
        if ct == "InpaintModelConditioning":                 # 출력 2 = 잠재 (그림 + 마스크)
            return ("image", self._image(ins["pixels"]), self._mask(ins["mask"]))
        if ct == "SetLatentNoiseMask":
            s = self._latent_src(ins["samples"])
            if s[0] == "empty":
                return s
            return ("image", s[1], self._mask(ins["mask"]))
        if ct in ("LatentUpscale", "LatentUpscaleBy"):
            s = self._latent_src(ins["samples"])
            if ct == "LatentUpscale":
                size = (int(self._val(ins.get("width")) or 1024), int(self._val(ins.get("height")) or 1024))
            else:
                f = float(self._val(ins.get("scale_by")) or 1.5)
                size = (int((s[1] if s[0] == "empty" else s[1].width) * f), int((s[2] if s[0] == "empty" else s[1].height) * f))
            if s[0] == "empty":
                return ("empty", size[0], size[1])
            return ("image", s[1].resize(size, Image.LANCZOS), s[2].resize(size) if s[2] is not None else None)
        if ct in ("RepeatLatentBatch", "LatentBatchSeedBehavior", "ModelSamplingAuraFlow"):
            return self._latent_src(ins.get("samples") or ins.get("latent"))
        raise NaiUnsupported("잠재 노드 %s" % ct)

    def _text(self, ref, want, depth=0):
        """조건 연결을 거슬러 올라가 글을 찾음 (want = positive / negative: 둘 다 내는 노드의 출력 번호로 고름)"""
        if depth > 30 or not isinstance(ref, list):
            return ""
        nid, ct, ins = self._node(ref)
        for k in ("text", "prompt", "text_g", "clip_l"):
            if isinstance(ins.get(k), str):
                return ins[k]
        if ct == "ConditioningZeroOut":
            return ""
        idx = int(ref[1]) if len(ref) > 1 else 0
        if "positive" in ins and "negative" in ins:          # ControlNetApplyAdvanced 등: 출력 0 = 긍정, 1 = 부정
            if "ControlNet" in ct or "LLLite" in ct:
                self._note("조종 그림(ControlNet/LLLite)은 NAI 에서 안 씀 — 글로만 그림")
            return self._text(ins["negative" if idx == 1 else "positive"], want, depth + 1)
        for k in ("conditioning", "conditioning_to", "cond", "cond_NEW", "conditioning_1", "conditioning_from", "conditioning_2",
                  "base_cond", "positive", "negative"):
            if isinstance(ins.get(k), list):
                t = self._text(ins[k], want, depth + 1)
                if t:
                    return t
        for k, v in ins.items():
            if isinstance(v, list) and len(v) == 2 and str(v[0]) in self._g and "cond" in k.lower():
                t = self._text(v, want, depth + 1)
                if t:
                    return t
        return ""

    def _sample(self, nid, ct, ins):
        if ct == "SamplerCustomAdvanced":
            guider = self._node(ins["guider"])[2]
            pos_ref = guider.get("positive") or guider.get("conditioning")
            neg_ref = guider.get("negative")
            noise = self._node(ins["noise"])[2] if isinstance(ins.get("noise"), list) else {}
            seed = self._val(noise.get("noise_seed"))
            lat = ins["latent_image"]
            sig = self._node(ins["sigmas"])[2] if isinstance(ins.get("sigmas"), list) else {}
            denoise = float(self._val(sig.get("denoise")) or 1.0)
        else:
            pos_ref, neg_ref, lat = ins.get("positive"), ins.get("negative"), ins.get("latent_image")
            seed = self._val(ins.get("seed", ins.get("noise_seed")))
            if ct == "KSamplerAdvanced":
                steps = int(self._val(ins.get("steps")) or 20)
                start = int(self._val(ins.get("start_at_step")) or 0)
                denoise = 1.0 - start / float(max(1, steps)) if str(ins.get("add_noise", "enable")) == "enable" else 0.0
            elif ct == "SamplerCustom":
                sig = self._node(ins["sigmas"])[2] if isinstance(ins.get("sigmas"), list) else {}
                denoise = float(self._val(sig.get("denoise")) or 1.0)
            else:
                denoise = float(self._val(ins.get("denoise")) if ins.get("denoise") is not None else 1.0)
        pos = self._text(pos_ref, "positive") if pos_ref else ""
        neg = self._text(neg_ref, "negative") if neg_ref else ""
        src = self._latent_src(lat)
        seed = int(seed) if isinstance(seed, (int, float)) else None
        if src[0] == "empty":
            return generate(pos, neg, src[1], src[2], seed)
        img, mask = src[1], src[2]
        if denoise <= 0.01:
            return img
        if mask is None and denoise >= 0.99:
            return generate(pos, neg, img.width, img.height, seed)
        return generate(pos, neg, img.width, img.height, seed, image=img, mask=mask, strength=denoise)


# ---------------------------------------------------------------- 🎨 NAI 직접 그리기 (작업실 /nai · 휴대폰 앱과 같은 화면)
SIZES = {"portrait": (832, 1216), "landscape": (1216, 832), "square": (1024, 1024), "tall": (768, 1344), "wide": (1344, 768)}
_NAME_RX = re.compile(r"^\d{8}_\d{6}_\d+\.png$")


def direct_dir(nk):
    d = os.path.join(nk.data_root(), "runs", "nai_direct")
    os.makedirs(d, exist_ok=True)
    return d


def direct(nk, b):
    """화면에서 온 요청 -> 그림 저장 -> {file, seed, width, height, model}"""
    prompt = str(b.get("prompt") or "").strip()
    if not prompt or len(prompt) > 6000:
        raise ValueError("프롬프트가 없거나 너무 김")
    size = SIZES.get(str(b.get("size") or ""))
    w, h = size or (int(b.get("width") or 832), int(b.get("height") or 1216))
    if not (64 <= w <= 1600 and 64 <= h <= 1600):
        raise ValueError("크기는 64~1600")
    chars = []
    for c in (b.get("chars") or [])[:6]:
        if str(c.get("prompt") or "").strip():
            chars.append({"prompt": str(c["prompt"])[:2000], "uc": str(c.get("uc") or "")[:2000],
                          "x": float(c.get("x", 0.5)), "y": float(c.get("y", 0.5))})
    over = {}
    if b.get("model") in MODELS:
        over["model"] = b["model"]
    for k, lo, hi in (("steps", 1, 50), ("scale", 0, 20)):
        if b.get(k) not in (None, ""):
            over[k] = max(lo, min(hi, float(b[k]) if k == "scale" else int(b[k])))
    if b.get("sampler") in ("k_euler_ancestral", "k_euler", "k_dpmpp_2s_ancestral", "k_dpmpp_2m_sde", "k_dpmpp_2m", "k_dpmpp_sde"):
        over["sampler"] = b["sampler"]
    seed = b.get("seed")
    seed = int(seed) if str(seed or "").strip().isdigit() else None
    im = generate(prompt, str(b.get("negative") or ""), w, h, seed, chars, user_prompt=bool(b.get("use_defaults", True)),
                  convert=False, **over)
    seed = generate.last_seed
    name = "%s_%d.png" % (time.strftime("%Y%m%d_%H%M%S"), seed)
    d = direct_dir(nk)
    im.save(os.path.join(d, name))
    meta = {"prompt": prompt, "negative": b.get("negative") or "", "chars": chars, "seed": seed, "width": w, "height": h,
            "model": over.get("model") or settings()["model"], "steps": over.get("steps"), "scale": over.get("scale"),
            "use_defaults": bool(b.get("use_defaults", True)), "time": time.strftime("%Y-%m-%d %H:%M:%S")}
    json.dump(meta, open(os.path.join(d, name[:-4] + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return dict(meta, file=name)


def direct_recent(nk, n=40):
    d = direct_dir(nk)
    out = []
    for f in sorted((x for x in os.listdir(d) if _NAME_RX.match(x)), reverse=True)[:n]:
        try:
            m = json.load(open(os.path.join(d, f[:-4] + ".json"), encoding="utf-8"))
        except Exception:
            m = {}
        out.append(dict(m, file=f))
    return out


def direct_file(nk, name):
    if not _NAME_RX.match(str(name or "")):
        return None
    p = os.path.join(direct_dir(nk), name)
    return open(p, "rb").read() if os.path.exists(p) else None


PROMPT_SYSTEM = """You turn a short Korean (or any language) picture description into a NovelAI Diffusion V5 prompt.
Rules:
- All-ages only. Never include sexual, nude, suggestive, gory or violent content; if asked, write a safe, wholesome version instead.
- No real people, no copyrighted characters by name.
- "prompt" = the scene: comma-separated Danbooru-style English tags (subject count like 1girl/2boys, setting, lighting, composition, art style),
  then optionally one short English sentence. Do not put character looks here when there are 2+ characters.
- "characters" = only when 2 or more people: one entry per person with that person's look and action as tags, and position x (0.1 left .. 0.9 right), y (0.5 = middle).
- "negative" = a few extra things to avoid (tags), may be empty.
Answer JSON only."""
PROMPT_SCHEMA = {"type": "object", "properties": {
    "prompt": {"type": "string"}, "negative": {"type": "string"},
    "characters": {"type": "array", "items": {"type": "object", "properties": {
        "prompt": {"type": "string"}, "uc": {"type": "string"}, "x": {"type": "number"}, "y": {"type": "number"}},
        "required": ["prompt", "x", "y"]}}},
    "required": ["prompt", "negative", "characters"]}


def prompt_from_text(text):
    """한국어 설명 -> {prompt, negative, characters} (Vertex AI)"""
    import nk_vertex
    text = str(text or "").strip()
    if not text or len(text) > 2000:
        raise ValueError("설명이 없거나 너무 김")
    raw = nk_vertex.chat([{"role": "system", "content": PROMPT_SYSTEM}, {"role": "user", "content": text}],
                         temperature=0.4, schema=PROMPT_SCHEMA, max_tokens=2048)
    m = re.search(r"\{.*\}", raw, re.S)
    d = json.loads(m.group(0) if m else raw)
    nk = _nk()
    return {"prompt": nk.safe_text(str(d.get("prompt") or "")) or "", "negative": str(d.get("negative") or ""),
            "characters": [{"prompt": nk.safe_text(str(c.get("prompt") or "")) or "", "uc": str(c.get("uc") or ""),
                            "x": _snap(c.get("x", 0.5)), "y": _snap(c.get("y", 0.5))} for c in (d.get("characters") or [])[:6]]}
