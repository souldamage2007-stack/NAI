# -*- coding: utf-8 -*-
"""Google Vertex AI (Gemini) 로 글 AI 를 씀 — Ollama 대신

쓰는 곳 (presets.yaml llm.backend: vertex 일 때, 기본)
  - 계획표 쓰기          nk ep write <ep> --backend vertex / nk ep auto <ep> --writer vertex / 작업실 '✨ AI가 바로 계획표'
  - 자동 검수 (그림 보기) nk.ollama_ask -> 그림 + 질문
  - 한국어 고치기 요청 해석 (nk_editcmd), 캐릭터 태그 찾기 (nk_charadd)

열쇠 = 서비스 계정 JSON (Google Cloud 콘솔 > IAM > 서비스 계정 > 키 > JSON).
  그 계정에 'Vertex AI 사용자(roles/aiplatform.user)' 역할, 프로젝트에 Vertex AI API 사용 설정이 있어야 함.
  넣기: nk ep keys --vertex 키.json  또는 작업실 ⚙ 설정. 열쇠는 키트 폴더 밖(nk_backend.keys_dir)에 둠.

외부 라이브러리 없이 urllib 로 부름. 서명(RS256)만 cryptography 패키지가 필요 (requirements.txt)."""
import os
import sys
import json
import time
import base64
import random
import urllib.request
import urllib.error

TOKEN_URL = "https://oauth2.googleapis.com/token"
SCOPE = "https://www.googleapis.com/auth/cloud-platform"
_tok = {"token": None, "exp": 0, "email": None}
_model_ok = [None]


class VertexError(RuntimeError):
    pass


def last_model():
    return _model_ok[0]


def _settings():
    import nk_backend
    s = {"model": "gemini-2.5-flash", "fallback": ["gemini-2.5-flash", "gemini-2.0-flash-001"], "location": "global",
         "temperature": 0.7, "max_tokens": 16384, "project": None, "timeout": 600, "retries": 5}
    s.update({k: v for k, v in nk_backend.llm_settings().items() if v not in (None, "")})
    if os.environ.get("NK_VERTEX_MODEL"):
        s["model"] = os.environ["NK_VERTEX_MODEL"]
    if os.environ.get("NK_VERTEX_LOCATION"):
        s["location"] = os.environ["NK_VERTEX_LOCATION"]
    return s


def _creds():
    import nk_backend
    p = nk_backend.vertex_json_path()
    if not p:
        raise VertexError("Vertex AI 서비스 계정 JSON 이 없음 -> 작업실 '⚙ 설정'에 넣거나 명령: nk ep keys --vertex 키.json")
    try:
        return nk_backend.check_vertex_json(open(p, encoding="utf-8").read())
    except ValueError as e:
        raise VertexError("%s (%s)" % (e, p))


def _b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def _sign(key_pem, data):
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
    except ImportError:
        raise VertexError("cryptography 패키지가 없음 -> python -m pip install cryptography")
    key = serialization.load_pem_private_key(key_pem.encode("utf-8"), password=None)
    return key.sign(data, padding.PKCS1v15(), hashes.SHA256())


def _token():
    if _tok["token"] and time.time() < _tok["exp"] - 120:
        return _tok["token"]
    c = _creds()
    now = int(time.time())
    head = _b64u(json.dumps({"alg": "RS256", "typ": "JWT", "kid": c.get("private_key_id", "")}).encode())
    claim = _b64u(json.dumps({"iss": c["client_email"], "scope": SCOPE, "aud": c.get("token_uri") or TOKEN_URL,
                              "iat": now, "exp": now + 3600}).encode())
    sig = _b64u(_sign(c["private_key"], (head + "." + claim).encode("ascii")))
    body = ("grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=" + head + "." + claim + "." + sig).encode()
    req = urllib.request.Request(c.get("token_uri") or TOKEN_URL, data=body,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        r = json.loads(urllib.request.urlopen(req, timeout=30).read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise VertexError("Google 로그인 실패 (%s): %s — JSON 키가 지워졌거나 시계가 틀렸을 수 있음"
                          % (e.code, e.read().decode("utf-8", "replace")[:300]))
    except (urllib.error.URLError, OSError) as e:
        raise VertexError("Google 에 연결할 수 없음: %s" % e)
    _tok.update(token=r["access_token"], exp=now + int(r.get("expires_in", 3600)), email=c["client_email"])
    return _tok["token"]


def _url(project, location, model):
    host = "aiplatform.googleapis.com" if location == "global" else "%s-aiplatform.googleapis.com" % location
    return "https://%s/v1/projects/%s/locations/%s/publishers/google/models/%s:generateContent" % (host, project, location, model)


def _mime(b64):
    if b64.startswith("/9j/"):
        return "image/jpeg"
    if b64.startswith("UklGR"):
        return "image/webp"
    return "image/png"


def _contents(messages):
    """Ollama 모양 메시지 [{role, content, images}] -> Vertex contents + systemInstruction"""
    system, contents = [], []
    for m in messages:
        role = str(m.get("role") or "user")
        text = str(m.get("content") or "")
        if role == "system":
            system.append(text)
            continue
        parts = []
        for b in m.get("images") or []:
            b = b.decode("ascii") if isinstance(b, bytes) else str(b)
            parts.append({"inlineData": {"mimeType": _mime(b), "data": b}})
        if text:
            parts.append({"text": text})
        if not parts:
            continue
        r = "model" if role == "assistant" else "user"
        if contents and contents[-1]["role"] == r:
            contents[-1]["parts"] += parts                 # 같은 쪽이 연달아 말하면 합침 (Gemini 규칙)
        else:
            contents.append({"role": r, "parts": parts})
    return contents, "\n\n".join(system)


def _schema(s):
    """JSON Schema (Ollama format) -> Vertex responseSchema (OpenAPI 부분집합, 타입 대문자)"""
    if not isinstance(s, dict):
        return None
    out = {}
    for k, v in s.items():
        if k == "type":
            out["type"] = str(v).upper()
        elif k == "properties" and isinstance(v, dict):
            out["properties"] = {pk: _schema(pv) for pk, pv in v.items()}
        elif k == "items":
            out["items"] = _schema(v)
        elif k in ("enum", "required", "description", "nullable", "format"):
            out[k] = v
    return out


def chat(messages, temperature=None, json_mode=False, schema=None, max_tokens=None, model=None):
    """메시지 -> 답 글. 실패하면 VertexError"""
    st = _settings()
    c = _creds()
    project = st.get("project") or c.get("project_id")
    contents, system = _contents(messages)
    if not contents:
        raise VertexError("보낼 글이 없음")
    gen = {"temperature": float(st["temperature"] if temperature is None else temperature),
           "maxOutputTokens": int(max_tokens or st["max_tokens"])}
    if json_mode or schema:
        gen["responseMimeType"] = "application/json"
    if schema:
        gen["responseSchema"] = _schema(schema)
    body = {"contents": contents, "generationConfig": gen}
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    models = [model] if model else []
    for m in [_model_ok[0], st["model"]] + list(st.get("fallback") or []):
        if m and m not in models:
            models.append(m)
    last = None
    for m in models:
        try:
            out = _call(_url(project, st["location"], m), body, st)
            _model_ok[0] = m
            return out
        except _NotFound as e:
            last = e
            print("   [Vertex] 모델 %s 없음 -> 다음 모델" % m)
            continue
    raise VertexError("쓸 수 있는 Gemini 모델이 없음 (%s). presets.yaml llm.model 을 콘솔 Model Garden 에 있는 이름으로 바꿔 줘: %s"
                      % (", ".join(models), last))


class _NotFound(Exception):
    pass


def _call(url, body, st):
    data = json.dumps(body).encode("utf-8")
    tries = int(st.get("retries", 5))
    for k in range(tries):
        req = urllib.request.Request(url, data=data, headers={"Authorization": "Bearer " + _token(),
                                                              "Content-Type": "application/json; charset=utf-8"})
        try:
            r = json.loads(urllib.request.urlopen(req, timeout=int(st.get("timeout", 600))).read().decode("utf-8"))
            return _text(r)
        except urllib.error.HTTPError as e:
            txt = e.read().decode("utf-8", "replace")
            if e.code == 404:
                raise _NotFound(txt[:200])
            if e.code == 401 and k < tries - 1:
                _tok["token"] = None
                continue
            if e.code in (429, 500, 502, 503, 504) and k < tries - 1:
                s = min(60, 2 * (2 ** k)) + random.random()
                print("   [Vertex] %s -> %.0f초 뒤 다시" % (e.code, s))
                time.sleep(s)
                continue
            if e.code == 403:
                raise VertexError("권한 없음 (403): 서비스 계정에 'Vertex AI 사용자' 역할을 주고, 프로젝트에서 Vertex AI API 를 켜 줘. %s" % txt[:300])
            raise VertexError("Vertex AI 오류 %s: %s" % (e.code, txt[:400]))
        except (urllib.error.URLError, OSError) as e:
            if k < tries - 1:
                time.sleep(min(30, 2 * (2 ** k)))
                continue
            raise VertexError("Vertex AI 에 연결할 수 없음: %s" % e)
    raise VertexError("Vertex AI 가 계속 응답하지 않음")


def _text(r):
    cands = r.get("candidates") or []
    if not cands:
        fb = r.get("promptFeedback") or {}
        raise VertexError("답이 없음 (%s)" % (fb.get("blockReason") or json.dumps(r)[:200]))
    c = cands[0]
    parts = (c.get("content") or {}).get("parts") or []
    out = "".join(p.get("text", "") for p in parts if not p.get("thought"))
    if not out.strip():
        raise VertexError("빈 답 (finishReason %s)" % c.get("finishReason"))
    if c.get("finishReason") == "MAX_TOKENS":
        print("   [Vertex] 답이 길이 한도에서 잘렸을 수 있음 (presets.yaml llm.max_tokens)")
    return out


def ollama_like(messages, temperature=None, json_mode=False, schema=None, max_tokens=None, model=None):
    """nk_plan._ollama_chat 자리: (글, Ollama 모양 기록) 을 돌려줌"""
    t0 = time.time()
    txt = chat(messages, temperature=temperature, json_mode=json_mode, schema=schema, max_tokens=max_tokens, model=model)
    return txt, {"message": {"role": "assistant", "content": txt}, "model": last_model(), "eval_count": None,
                 "total_duration": int((time.time() - t0) * 1e9)}
