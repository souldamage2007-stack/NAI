package com.niko.comicmaker;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Iterator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * 만화 작업실 앱.
 * - 첫 화면 = https://appassets.androidplatform.net/nai.html (앱 안의 assets/nai.html 을 이 주소로 보여 줌 = 안전한 출처라 IndexedDB 등이 됨)
 *   assets/nai.html (저장소 web/nai.html 과 같은 파일): 🎨 NAI 직접 그리기, ✨ Vertex AI 프롬프트, ⚙ 열쇠, 💻 PC 작업실 열기
 * - 휴대폰이 직접 NAI / Vertex AI 에 요청 (이 클래스의 Bridge = window.NKAndroid). 열쇠는 이 앱 안(SharedPreferences)에만 저장
 * - PC 작업실 주소(휴대폰 모드, :8765)를 열면 만화 전체 만들기를 그대로 씀
 * Bridge 는 앱 안의 화면(appassets 주소)에서만 움직임 — PC 작업실 같은 바깥 페이지는 열쇠·요청을 못 씀
 */
public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";   // 안드로이드가 앱 안 파일용으로 비워 둔 주소 (진짜 사이트 없음)
    static final String ORIGIN = "https://" + HOST + "/";
    static final String HOME = ORIGIN + "nai.html";
    static final int PICK = 41;

    WebView web;
    volatile String curUrl = "";
    ValueCallback<Uri[]> fileCb;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("nk", MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.parseColor("#2f6fdb"));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);          // 앱 화면은 appassets 주소로 (위 shouldInterceptRequest)
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "NKAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                curUrl = url == null ? "" : url;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String path = u.getPath();
                if (path == null || path.equals("/") || path.isEmpty()) path = "/nai.html";
                if (path.contains("..")) return notFound();
                try {
                    InputStream in = getAssets().open(path.substring(1));
                    String mime = path.endsWith(".html") ? "text/html" : path.endsWith(".js") ? "text/javascript"
                            : path.endsWith(".css") ? "text/css" : path.endsWith(".png") ? "image/png" : "application/octet-stream";
                    return new WebResourceResponse(mime, "utf-8", in);
                } catch (IOException e) {
                    return notFound();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                curUrl = url;
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false;               // 앱 안에서 엶
                }
                openOutside(url);
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {   // alert/confirm 창, <input type=file> (Vertex JSON 고르기)
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "파일 고르기"), PICK);
                } catch (ActivityNotFoundException e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });
        web.setDownloadListener(new DownloadListener() {  // PC 작업실의 PDF·그림 내려받기 -> 휴대폰 브라우저로
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                openOutside(url);
            }
        });
        setContentView(web);
        if (b != null) {
            web.restoreState(b);
        } else {
            open(getIntent());
        }
    }

    void open(Intent i) {
        Uri u = i == null ? null : i.getData();
        if (u != null && "http".equals(u.getScheme())) {
            prefs.edit().putString("pc_url", u.toString()).apply();
            curUrl = u.toString();
            web.loadUrl(u.toString());
        } else {
            curUrl = HOME;
            web.loadUrl(HOME);
        }
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i != null && i.getData() != null) open(i);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else if (!local()) {
            curUrl = HOME;
            web.loadUrl(HOME);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PICK && fileCb != null) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null && data.getData() != null) r = new Uri[]{data.getData()};
            fileCb.onReceiveValue(r);
            fileCb = null;
        }
    }

    static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
    }

    void openOutside(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "열 수 없음: " + url, Toast.LENGTH_LONG).show();
        }
    }

    boolean local() {
        return curUrl.startsWith(ORIGIN);
    }

    void reply(final String id, final JSONObject o) {
        final String js = "window.NKcb(" + JSONObject.quote(id) + "," + JSONObject.quote(o.toString()) + ")";
        web.post(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    static byte[] readAll(InputStream in) throws Exception {
        if (in == null) return new byte[0];
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toByteArray();
    }

    static byte[] firstPng(byte[] zip) throws Exception {
        if (zip.length > 8 && (zip[0] & 0xff) == 0x89 && zip[1] == 'P') return zip;   // 이미 PNG
        ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(zip));
        ZipEntry e;
        while ((e = z.getNextEntry()) != null) {
            if (e.getName().toLowerCase().endsWith(".png")) return readAll(z);
        }
        return null;
    }

    /** window.NKAndroid */
    class Bridge {
        @JavascriptInterface
        public String prefGet(String k) {
            if (!local()) return "";
            return prefs.getString(k, "");
        }

        @JavascriptInterface
        public void prefSet(String k, String v) {
            if (!local()) return;
            prefs.edit().putString(k, v).apply();
        }

        @JavascriptInterface
        public String version() {
            return "1.0";
        }

        /** HTTP 한 번 (뒤에서) -> NKcb(id, {status, body(base64), ctype, png?, error?}). mode "zip-png" = NAI 답 zip 에서 PNG 꺼냄 */
        @JavascriptInterface
        public void http(final String id, final String method, final String url, final String headersJson, final String bodyB64,
                         final String mode) {
            if (!local()) return;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    JSONObject o = new JSONObject();
                    HttpURLConnection c = null;
                    try {
                        c = (HttpURLConnection) new URL(url).openConnection();
                        c.setRequestMethod(method);
                        c.setConnectTimeout(30000);
                        c.setReadTimeout(240000);
                        JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                        Iterator<String> it = h.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            c.setRequestProperty(k, h.getString(k));
                        }
                        if (bodyB64 != null && !bodyB64.isEmpty()) {
                            byte[] body = Base64.decode(bodyB64, Base64.DEFAULT);
                            c.setDoOutput(true);
                            c.setFixedLengthStreamingMode(body.length);
                            OutputStream os = c.getOutputStream();
                            os.write(body);
                            os.close();
                        }
                        int code = c.getResponseCode();
                        byte[] data = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
                        o.put("status", code);
                        o.put("ctype", String.valueOf(c.getContentType()));
                        if (code == 200 && "zip-png".equals(mode)) {
                            byte[] png = firstPng(data);
                            if (png == null) {
                                o.put("status", 599);
                                o.put("body", Base64.encodeToString("NAI 답에 그림이 없음".getBytes("UTF-8"), Base64.NO_WRAP));
                            } else {
                                o.put("png", Base64.encodeToString(png, Base64.NO_WRAP));
                            }
                        } else {
                            o.put("body", Base64.encodeToString(data, Base64.NO_WRAP));
                        }
                    } catch (Exception e) {
                        try {
                            o.put("error", e.toString());
                        } catch (Exception ignored) {
                        }
                    } finally {
                        if (c != null) c.disconnect();
                    }
                    reply(id, o);
                }
            }).start();
        }

        /** RS256 서명 (Vertex AI 서비스 계정 로그인): PEM(PKCS8) 열쇠 + base64 데이터 -> base64 서명. 실패 = "ERR: ..." */
        @JavascriptInterface
        public String sign(String pem, String dataB64) {
            if (!local()) return "ERR: not allowed";
            try {
                String k = pem.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "")
                        .replace("\\n", "").replaceAll("\\s", "");
                PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(Base64.decode(k, Base64.DEFAULT)));
                Signature sg = Signature.getInstance("SHA256withRSA");
                sg.initSign(key);
                sg.update(Base64.decode(dataB64, Base64.DEFAULT));
                return Base64.encodeToString(sg.sign(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "ERR: " + e;
            }
        }

        /** 그림을 갤러리(사진/NikoComic)에 저장 -> NKcb(id, {ok, msg}) */
        @JavascriptInterface
        public void saveImage(final String id, final String pngB64, final String name) {
            if (!local()) return;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    JSONObject o = new JSONObject();
                    try {
                        byte[] png = Base64.decode(pngB64, Base64.DEFAULT);
                        String fn = name.replaceAll("[^A-Za-z0-9_.-]", "_");
                        if (Build.VERSION.SDK_INT >= 29) {
                            ContentValues v = new ContentValues();
                            v.put(MediaStore.MediaColumns.DISPLAY_NAME, fn);
                            v.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NikoComic");
                            ContentResolver cr = getContentResolver();
                            Uri u = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                            if (u == null) throw new Exception("갤러리에 자리를 못 만듦");
                            OutputStream os = cr.openOutputStream(u);
                            os.write(png);
                            os.close();
                            o.put("ok", true);
                            o.put("msg", "갤러리 사진/NikoComic 에 저장함");
                        } else {
                            File d = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "NikoComic");
                            d.mkdirs();
                            File f = new File(d, fn);
                            FileOutputStream os = new FileOutputStream(f);
                            os.write(png);
                            os.close();
                            o.put("ok", true);
                            o.put("msg", "저장함: " + f.getAbsolutePath());
                        }
                    } catch (Exception e) {
                        try {
                            o.put("ok", false);
                            o.put("msg", e.toString());
                        } catch (Exception ignored) {
                        }
                    }
                    reply(id, o);
                }
            }).start();
        }
    }
}
